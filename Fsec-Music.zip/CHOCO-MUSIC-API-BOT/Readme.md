# Music
A Powerful Music Bot For Telegram Users 
![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=600&size=31&duration=4500&pause=1000&color=RED&multiline=true&width=453&height=100&lines=FALCON+SECURITY)

#  FSEC_MUSIC

         ╔═══════════════╗
         ║𝙐𝙉𝙀𝙈𝙋𝙇𝙊𝙄𝘿-𝙃𝘼𝘾𝙆𝙀𝙍║    
         ╚═══════════════╝


     
     
             FSEC_MUSIC  
     
       ╠═════════════════╣


## 𝘼𝘽𝙊𝙐𝙏 𝙏𝙃𝙄𝙎 𝙏𝙊𝙊𝙇
➢ A POWERFUL MUSIC BOT FOR TELEGRAM GROUP/CHANNEL VOICE CHAT

<h3> 𝗛𝗘𝗥𝗢𝗞𝗨 𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗕𝗨𝗧𝗧𝗢𝗡 </h3>
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/codex-ML/CHOCO-MUSIC-API-BOT"> <img src="https://graph.org/file/cb9394eec3d0ebce858f9.jpg" width="620" height="198.45"/></a></p>
